# Review scenario
This is an educational reconstruction of the public September 2018 Amazon valuation model, not an actual client engagement or a current investment recommendation.

The additional case has a terminal operating-margin target 2 percentage points below the original base case. All other assumptions and the model's transition convention remain the same. Include the equity-value difference between the two cases.

For this reconstruction, the historical lease financing rate is fixed at the unique self-consistent solution of the original rating and lease method. The supplied workbook identifies this construction adjustment and retains the underlying historical commitments and rating table. Treat the historical financing basis and other historical assumptions as fixed. Independently changing five-year forecast growth, the target operating margin or the initial cost of capital should update both the base and review valuations. The review target remains 2 percentage points below the current base target, using the original transition convention.

## Base and review cases

The workbook keeps the original base case on `Valuation output` and adds the linked review case on `Review valuation`.

| Case | Terminal operating-margin target | Equity value | Equity value per share |
| --- | ---: | ---: | ---: |
| Original base case | 12.50% | 623,759.2 | 1,255.05 |
| Review case | 10.50% | 518,362.3 | 1,042.98 |
| Review less base | -2.00% | -105,396.9 | -212.07 |

The difference is driven only by the lower review operating-margin target. Lower margins reduce after-tax operating income, FCFF and the terminal cash flow; the historical lease-financing basis, five-year growth, reinvestment convention, terminal growth and discount-rate convention remain unchanged. Editing the growth, base target margin or initial cost of capital on `Input sheet` updates both valuations; the review target remains the current base target minus 2 percentage points.
