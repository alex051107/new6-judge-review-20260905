# September 2018 Amazon Valuation Review

This is an educational reconstruction of the public September 2018 Amazon valuation model, not an actual client engagement or a current investment recommendation.

## Original base case

The original September 2018 base-case inputs are retained in the workbook's `Input sheet`:

- Five-year compounded revenue growth: 15.0%
- Terminal pre-tax operating-margin target: 12.5%
- Initial cost of capital: 7.97%
- Historical pre-tax lease financing rate: 4.13% (fixed construction input)

With the restored forecast, cash-flow, and equity bridge, the base case produces an equity value of $623.8 billion, or $1,255.05 per share. Dollar figures are in millions except per-share amounts.

## Review scenario

The additional case retains the original growth, discount-rate, historical financing basis, and transition convention. Its terminal operating-margin target is formula-linked to the base target less 2.0 percentage points, which is 10.5% at the current base input.

The review case produces an equity value of $518.4 billion, or $1,042.98 per share. This is $105.4 billion, or $212.07 per share, below the original base case. The difference reflects the lower operating-margin target and its transition path; it is not driven by a changed growth or discount-rate assumption.

## Basis retained for review

For this reconstruction, the historical lease financing rate is fixed at the unique self-consistent solution of the original rating and lease method. The supplied workbook identifies this construction adjustment and retains the underlying historical commitments and rating table. Treat the historical financing basis and other historical assumptions as fixed.

Independently changing five-year forecast growth, the base target operating margin, or the initial cost of capital updates both the base and review valuations. The review target remains 2 percentage points below the current base target, using the original transition convention.

Source: Aswath Damodaran, AmazonSept18.xlsx, September 2018. Project construction adjustment; the original supporting schedules are retained in the workbook.
