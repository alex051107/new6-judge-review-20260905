# Review scenario
This is an educational reconstruction of the public September 2018 Amazon valuation model, not an actual client engagement or a current investment recommendation.

The additional case has a terminal operating-margin target 2 percentage points below the original base case. All other assumptions and the model's transition convention remain the same. Include the equity-value difference between the two cases.

For this reconstruction, the historical lease financing rate is fixed at the unique self-consistent solution of the original rating and lease method. The supplied workbook identifies this construction adjustment and retains the underlying historical commitments and rating table. Treat the historical financing basis and other historical assumptions as fixed. Independently changing five-year forecast growth, the target operating margin or the initial cost of capital should update both the base and review valuations. The review target remains 2 percentage points below the current base target, using the original transition convention.

## Restored comparison at the supplied inputs

The workbook retains the original base case on `Valuation output` and adds a linked `Review scenario` schedule. Both cases use the same 15.0% five-year revenue growth, 7.97% initial cost of capital, historical financing basis and transition timing. The review case sets the terminal operating-margin target to 10.5% (12.5% base target less 2.0 percentage points).

At those inputs:

- Original base case equity value: $1,027,090.7 million ($2,066.58/share).
- Review scenario equity value: $850,512.9 million ($1,711.29/share).
- Difference (review less base): -$176,577.7 million (-$355.29/share), or -17.2%.

The difference is driven by lower after-tax operating income during the transition and a lower terminal cash flow/value. Change the shared growth, base target margin or initial cost of capital inputs to update both schedules; the review target remains base target minus 2.0 percentage points.
