# Review scenario
This is an educational reconstruction of the public September 2018 Amazon valuation model, not an actual client engagement or a current investment recommendation.

The additional case has a terminal operating-margin target 2 percentage points below the original base case. All other assumptions and the model's transition convention remain the same. Include the equity-value difference between the two cases.

For this reconstruction, the historical lease financing rate is fixed at the unique self-consistent solution of the original rating and lease method. The supplied workbook identifies this construction adjustment and retains the underlying historical commitments and rating table. Treat the historical financing basis and other historical assumptions as fixed. Independently changing five-year forecast growth, the target operating margin or the initial cost of capital should update both the base and review valuations. The review target remains 2 percentage points below the current base target, using the original transition convention.

## Cases retained in the completed workbook

- **Original base case:** five-year growth, base terminal operating-margin target and initial cost of capital remain on the `Input sheet`; the completed schedules and valuation are on `Valuation output`.
- **Review case:** identical historical basis, growth, tax, reinvestment, failure and discounting assumptions, with terminal operating margin set to `Input sheet!B24 - 2.0%`; the completed schedules and valuation are on `Review scenario`.

At the supplied inputs, the base case equity value is approximately **$581,922 million** ($1,170.87/share) and the review case is approximately **$476,525 million** ($958.80/share). The review is lower by approximately **$105,397 million**, or **$212.07/share**. This difference is the value impact of the lower terminal margin under the same transition convention. The comparison cells on `Review scenario` remain formula-linked so changes to five-year growth, target margin or initial cost of capital update both cases.
